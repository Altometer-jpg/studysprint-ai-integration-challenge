# Evidence checklist — AI Integration Challenge

Capture screenshots from your own account after completing each real action. Do not fabricate screenshots or connection states.

- [ ] Screenshot: AI platform showing connected apps/integrations.
- [ ] Screenshot: prompt asking the AI to create the StudySprint concept brief and deliverables.
- [x] Dedicated Canva project folder created: https://www.canva.com/folder/FAHYu7dCLxY
- [x] Canva presentation created: https://canva.link/9kvzyghavnvjupz
- [x] Dedicated Notion project hub created: https://app.notion.com/p/40113665de3a8106a461fbdf5b3d86f8
- [x] Notion task tracker created: https://app.notion.com/p/256e7473d4464ced91b7ba92ba3e5adb
- [ ] Create a new GitHub repository named `studysprint-ai-integration-challenge` and upload the standalone prototype and project brief.
- [ ] Screenshot: the new GitHub repository and its visible files.
- [ ] Screenshot: how the project brief was used to create the Canva presentation and website prototype.
- [ ] Add screenshots to this evidence folder and submit the folder/archive in Canvas.

## Final links
- Canva presentation: https://canva.link/9kvzyghavnvjupz
- Canva folder: https://www.canva.com/folder/FAHYu7dCLxY
- Notion project hub: https://app.notion.com/p/40113665de3a8106a461fbdf5b3d86f8
- Notion task tracker: https://app.notion.com/p/256e7473d4464ced91b7ba92ba3e5adb
- GitHub repository: add after you create it

## Reflection draft (edit to match the actions you actually completed)
I used an AI platform as a central workspace to develop StudySprint, then organized the project brief and task roadmap in Notion and created a visual presentation in Canva. I also prepared a static website prototype and project documentation for a separate GitHub repository. StudySprint remains a concept; user research and performance metrics have not yet been validated.
