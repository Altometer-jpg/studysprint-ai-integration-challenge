# AI Integration Challenge — StudySprint

This is a standalone concept project created for the AI Integration Challenge.

## Connected-app outputs
- **Canva presentation:** https://canva.link/9kvzyghavnvjupz
- **Canva project folder:** https://www.canva.com/folder/FAHYu7dCLxY
- **Notion project hub:** https://app.notion.com/p/40113665de3a8106a461fbdf5b3d86f8
- **Notion task tracker:** https://app.notion.com/p/256e7473d4464ced91b7ba92ba3e5adb
- **GitHub repository:** not created yet. The available GitHub connection can read repositories and create files inside an existing repository, but it did not expose a create-repository action. Create a new repository named `studysprint-ai-integration-challenge` and upload the `website/` and `project_docs/` files to keep this project separate from existing work.

## Contents
- `project_docs/StudySprint_Project_Brief.md` — concept, workflow, MVP, roadmap, risks, and proposed metrics.
- `website/index.html` — responsive static landing-page prototype.
- `evidence/EVIDENCE_CHECKLIST.md` — checklist for collecting real evidence from connected apps.

## Important
StudySprint is a fictional concept. Do not claim user interviews, product launch, or measured results occurred unless you actually complete them. The Canva presentation and Notion project hub have been created; the GitHub repository and evidence screenshots remain to be completed.
